function getXmlHttp() 
{
    var xmlHttp;
    if (window.XMLHttpRequest)
    { // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlHttp = new XMLHttpRequest();
    } 
    else
    { // code for IE6, IE5
        xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
    }
    return xmlHttp;
}

var sslEnable = false;


function getHttpObj(actionName)
{
	var httpObj = getXmlHttp();
	var URL = "http://127.0.0.1:9528/Service1.asmx";
	if(sslEnable)
	{
		URL = "https://127.0.0.1:18981/Service1.asmx";
	}
	httpObj.open('POST', URL, false);//同步请求数据,异步是true
	httpObj.setRequestHeader('Content-Type', 'text/xml; charset=utf-8');//设置请求头类型及编码
	//httpObj.setRequestHeader('Content-Security-Policy', 'upgrade-insecure-requests');
	//httpObj.setRequestHeader('Access-Control-Allow-Origin', '*');
	httpObj.setRequestHeader('SOAPAction', 'http://tempuri.org/' + actionName);//设置Action
	//httpObj.setRequestHeader('If-Modified-Since', '0');
	httpObj.setRequestHeader('Cache-Control', 'no-cache');
	//httpObj.setRequestHeader('Connection', 'keey-alive');
	//httpObj.setRequestHeader('Keep-Alive', '30');
	return httpObj;
}

function getRequestData(actionName, actionObj)
{
	var data = '<?xml version="1.0" encoding="utf-8"?>';
    
  data += '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">';
  data += '<soap:Body>';

	
	if(actionObj != null)
	{
		data += '<' + actionName + ' xmlns="http://tempuri.org">';
		for(items in actionObj)
		{
			data += '<' + items + '>' + actionObj[items] + '</' + items + '>';  
		}
		data += '</' + actionName + '>';
	}
	else
	{
		data += '<' + actionName + ' xmlns="http://tempuri.org" />';
	}
	data += '</soap:Body>';
	data += '</soap:Envelope>';
	return data;
}

function getResponseData(actionName, response)
{
	var parseXml;
	var xmlDoc;
	var ret;
	if (typeof window.DOMParser != "undefined") 
	{	
		parseXml = new window.DOMParser();
		xmlDoc = parseXml.parseFromString(response, "text/xml");
		
		if(actionName == 'SZCAInit')
		{
			ret = xmlDoc.getElementsByTagName('bInit')[0].textContent;
		}
		else if(actionName == 'SZCAKeyIsExist')
		{
			ret = xmlDoc.getElementsByTagName('isExist')[0].textContent;
		}
		else if(actionName == 'SZCASign')
		{
			ret = xmlDoc.getElementsByTagName('outData')[0].textContent;
		}
		else if(actionName == 'SZCAGetCertData')
		{
			ret = xmlDoc.getElementsByTagName('certData')[0].textContent;
		}	
		else if(actionName == 'SZCAGetCertInfo')
		{
			ret = xmlDoc.getElementsByTagName('infoData')[0].textContent;
		}
		else if(actionName == 'SZCAVerify')
		{
			ret = xmlDoc.getElementsByTagName('bVerify')[0].textContent;
		}
		else if(actionName == 'SZCASignMessage')
		{
			ret = xmlDoc.getElementsByTagName('outData')[0].textContent;
		}
		else if(actionName == 'SZCAVerifyMessage')
		{
			ret = xmlDoc.getElementsByTagName('bVerify')[0].textContent;
		}
		else if(actionName == 'SZCAParseSignMessage')
		{
			ret = xmlDoc.getElementsByTagName('infoData')[0].textContent;
		}
		else if(actionName == 'SZCAParseCertData')
		{
			ret = xmlDoc.getElementsByTagName('infoData')[0].textContent;
		}
		else if(actionName == 'SZCAVerifyUserPin')
		{
			ret = xmlDoc.getElementsByTagName('bPass')[0].textContent;
		}
		return ret;
	} 
	else if (typeof window.ActiveXObject != "undefined" &&
       new window.ActiveXObject("Microsoft.XMLDOM")) 
	{
		xmlDoc = new window.ActiveXObject("Microsoft.XMLDOM");
		xmlDoc.async = false;
		var loadSucc = xmlDoc.loadXML(response);		
		if(actionName == 'SZCAInit')
		{
			ret = xmlDoc.getElementsByTagName('bInit')[0].textContent;
			if(ret == undefined)
			{
				ret = xmlDoc.getElementsByTagName('bInit')[0].text;
			}
		}
		else if(actionName == 'SZCAKeyIsExist')
		{
			ret = xmlDoc.getElementsByTagName('isExist')[0].textContent;
			if(ret == undefined)
			{
				ret = xmlDoc.getElementsByTagName('isExist')[0].text;
			}
		}
		else if(actionName == 'SZCASign')
		{
			ret = xmlDoc.getElementsByTagName('outData')[0].textContent;
			if(ret == undefined)
			{
				ret = xmlDoc.getElementsByTagName('outData')[0].text;
			}
		}
		else if(actionName == 'SZCAGetCertData')
		{
			ret = xmlDoc.getElementsByTagName('certData')[0].textContent;
			if(ret == undefined)
			{
				ret = xmlDoc.getElementsByTagName('certData')[0].text;
			}
		}	
		else if(actionName == 'SZCAGetCertInfo')
		{
			ret = xmlDoc.getElementsByTagName('infoData')[0].textContent;
			if(ret == undefined)
			{
				ret = xmlDoc.getElementsByTagName('infoData')[0].text;
			}
		}
		else if(actionName == 'SZCAVerify')
		{
			ret = xmlDoc.getElementsByTagName('bVerify')[0].textContent;
			if(ret == undefined)
			{
				ret = xmlDoc.getElementsByTagName('bVerify')[0].text;
			}
		}
		else if(actionName == 'SZCASignMessage')
		{
			ret = xmlDoc.getElementsByTagName('outData')[0].textContent;
			if(ret == undefined)
			{
				ret = xmlDoc.getElementsByTagName('outData')[0].text;
			}
		}
		else if(actionName == 'SZCAVerifyMessage')
		{
			ret = xmlDoc.getElementsByTagName('bVerify')[0].textContent;
			if(ret == undefined)
			{
				ret = xmlDoc.getElementsByTagName('bVerify')[0].text;
			}
		}
		else if(actionName == 'SZCAParseSignMessage')
		{
			ret = xmlDoc.getElementsByTagName('infoData')[0].textContent;
			if(ret == undefined)
			{
				ret = xmlDoc.getElementsByTagName('infoData')[0].text;
			}
		}
		else if(actionName == 'SZCAParseCertData')
		{
			ret = xmlDoc.getElementsByTagName('infoData')[0].textContent;
			if(ret == undefined)
			{
				ret = xmlDoc.getElementsByTagName('infoData')[0].text;
			}
		}
		else if(actionName == 'SZCAVerifyUserPin')
		{
			ret = xmlDoc.getElementsByTagName('bPass')[0].textContent;
			if(ret == undefined)
			{
				ret = xmlDoc.getElementsByTagName('bPass')[0].text;
			}
		}
		return ret;
	} 
	else 
	{
		throw new Error("No XML parser found");
	}	
}

function NotifyClient() {
    alert("您没有安装SZCA客户端软件或您的客户端软件版本较低！");
}

function SZCASSLEnable(bEnable)
{
	sslEnable = bEnable;
}
	
function SZCAInit()
{
	var xmlHttp = getHttpObj('SZCAInit');
	var data = getRequestData('SZCAInit', null);
	try
	{
		xmlHttp.send(data);
	}
	catch(e)
	{
		NotifyClient();
		return false;
	}
	if(xmlHttp.status == 200)
	{
		try
		{	var retValue = getResponseData('SZCAInit', xmlHttp.response);
			if(parseInt(retValue) != 0)
			{
				return true;
			} 
		}
		catch(e)
		{
			var retValue = getResponseData('SZCAInit', xmlHttp.responseText);
			if(parseInt(retValue) != 0)
			{
				return true;
			}
		}
		
	}
	else
	{
		NotifyClient();
	}
	return false;
}
	
function SZCAKeyIsExist()
{
	var xmlHttp = getHttpObj('SZCAKeyIsExist');
	var data = getRequestData('SZCAKeyIsExist', null);
	try
	{
		xmlHttp.send(data);
	}
	catch(e)
	{
		NotifyClient();
		return false;
	}
	if(xmlHttp.status == 200)
	{
		try
		{
			var retValue = getResponseData('SZCAKeyIsExist', xmlHttp.response);
			if(parseInt(retValue) != 0)
			{
				return true;
			}
		}
		catch(e)
		{
			var retValue = getResponseData('SZCAKeyIsExist', xmlHttp.responseText);
			if(parseInt(retValue) != 0)
			{
				return true;
			}
		}
		
	}
	else
	{
		NotifyClient();
	}
	return false;
}

function SZCASign(inData)
{
	var xmlHttp = getHttpObj('SZCASign');
	var obj = new Object();
	var inDataB64 = base64encode(utf16to8(inData));
	obj.inData = inDataB64;
	var data = getRequestData('SZCASign', obj);
	try
	{
		xmlHttp.send(data);
	}
	catch(e)
	{
		NotifyClient();
		return false;
	}
	if(xmlHttp.status == 200)
	{
		try
		{
			var retValue = getResponseData('SZCASign', xmlHttp.response);
			return retValue;
		}
		catch(e)
		{
			var retValue = getResponseData('SZCASign', xmlHttp.responseText);
			return retValue;
		}
		
	}
	else
	{
		NotifyClient();
	}
	return "";
}

function SZCAVerify(signedData, certData, srcData)
{
	var xmlHttp = getHttpObj('SZCAVerify');
	var obj = new Object();
	var signedDataB64 = base64encode(utf16to8(signedData));
	var certDataB64 = base64encode(utf16to8(certData));
	var srcDataB64 = base64encode(utf16to8(srcData));	
	obj.signedData = signedDataB64;
	obj.certData = certDataB64;
	obj.srcData = srcDataB64;	
	var data = getRequestData('SZCAVerify', obj);
	try
	{
		xmlHttp.send(data);
	}
	catch(e)
	{
		NotifyClient();
		return false;
	}
	if(xmlHttp.status == 200)
	{
		try
		{
			var retValue = getResponseData('SZCAVerify', xmlHttp.response);
			return retValue;
		}
		catch(e)
		{
			var retValue = getResponseData('SZCAVerify', xmlHttp.responseText);
			return retValue;
		}
		
	}
	else
	{
		NotifyClient();
	}
	return "";
}

function SZCASignMessage(inData, bDetach)
{
	var xmlHttp = getHttpObj('SZCASignMessage');
	var obj = new Object();
	var inDataB64 = base64encode(utf16to8(inData));
	obj.inData = inDataB64;
	obj.bDetach = bDetach;
	var data = getRequestData('SZCASignMessage', obj);
	try
	{
		xmlHttp.send(data);
	}
	catch(e)
	{
		NotifyClient();
		return false;
	}
	if(xmlHttp.status == 200)
	{
		try
		{
			var retValue = getResponseData('SZCASignMessage', xmlHttp.response);
			return retValue;
		}
		catch(e)
		{
			var retValue = getResponseData('SZCASignMessage', xmlHttp.responseText);
			return retValue;
		}
		
	}
	else
	{
		NotifyClient();
	}
	return "";
}

function SZCAVerifyMessage(signedData, srcData)
{
	var xmlHttp = getHttpObj('SZCAVerifyMessage');
	var obj = new Object();
	var signedDataB64 = base64encode(utf16to8(signedData));
	var srcDataB64 = base64encode(utf16to8(srcData));
	obj.signedData = signedDataB64;
	obj.srcData = srcDataB64;
	var data = getRequestData('SZCAVerifyMessage', obj);
	try
	{
		xmlHttp.send(data);
	}
	catch(e)
	{
		NotifyClient();
		return false;
	}
	if(xmlHttp.status == 200)
	{
		try
		{
			var retValue = getResponseData('SZCAVerifyMessage', xmlHttp.response);
			return retValue;
		}
		catch(e)
		{
			var retValue = getResponseData('SZCAVerifyMessage', xmlHttp.responseText);
			return retValue;
		}
		
	}
	else
	{
		NotifyClient();
	}
	return "";
}

function SZCAGetCertData(certType, dataType)
{
	var xmlHttp = getHttpObj('SZCAGetCertData');
	var obj = new Object();
	obj.certType = certType;
	obj.dataType = dataType;
	var data = getRequestData('SZCAGetCertData', obj);
	try
	{
		xmlHttp.send(data);
	}
	catch(e)
	{
		NotifyClient();
		return false;
	}
	if(xmlHttp.status == 200)
	{
		try
		{
			var retValue = getResponseData('SZCAGetCertData', xmlHttp.response);
			return retValue;
		}
		catch(e)
		{
			var retValue = getResponseData('SZCAGetCertData', xmlHttp.responseText);
			return retValue;
		}
		
	}
	else
	{
		NotifyClient();
	}
	return "";
}

function SZCAGetCertInfo(infoType, infoKey)
{
	var xmlHttp = getHttpObj('SZCAGetCertInfo');
	var obj = new Object();
	obj.infoType = infoType;
	obj.infoKey = infoKey;
	var data = getRequestData('SZCAGetCertInfo', obj);
	try
	{
		xmlHttp.send(data);
	}
	catch(e)
	{
		NotifyClient();
		return false;
	}
	if(xmlHttp.status == 200)
	{
		try
		{
			var retValueB64 = getResponseData('SZCAGetCertInfo', xmlHttp.response);
			var retValue = utf8to16(base64decode(retValueB64));
			return retValue;
		}
		catch(e)
		{
			var retValueB64 = getResponseData('SZCAGetCertInfo', xmlHttp.responseText);
			var retValue = utf8to16(base64decode(retValueB64));
			return retValue;
		}
			
	}
	else
	{
		NotifyClient();
	}
	return "";
}

function SZCAParseSignMessage(signedData, nType)
{
	var xmlHttp = getHttpObj('SZCAParseSignMessage');
	var obj = new Object();
	var signedDataB64 = base64encode(utf16to8(signedData));
	obj.signedData = signedDataB64;
	obj.nType = nType;
	var data = getRequestData('SZCAParseSignMessage', obj);
	try
	{
		xmlHttp.send(data);
	}
	catch(e)
	{
		NotifyClient();
		return false;
	}
	if(xmlHttp.status == 200)
	{
		try
		{
			var retValueB64 = getResponseData('SZCAParseSignMessage', xmlHttp.response);
			var retValue = utf8to16(base64decode(retValueB64));
			return retValue;
		}
		catch(e)
		{
			var retValueB64 = getResponseData('SZCAParseSignMessage', xmlHttp.responseText);
			var retValue = utf8to16(base64decode(retValueB64));
			return retValue;
		}
			
	}
	else
	{
		NotifyClient();
	}
	return "";
}

function SZCAParseCertData(certData, nType)
{
	var xmlHttp = getHttpObj('SZCAParseCertData');
	var obj = new Object();
	var certDataB64 = base64encode(utf16to8(certData));
	obj.certData = certDataB64;
	obj.nType = nType;
	var data = getRequestData('SZCAParseCertData', obj);
	try
	{
		xmlHttp.send(data);
	}
	catch(e)
	{
		NotifyClient();
		return false;
	}
	if(xmlHttp.status == 200)
	{
		try
		{
			var retValueB64 = getResponseData('SZCAParseCertData', xmlHttp.response);
			var retValue = utf8to16(base64decode(retValueB64));
			return retValue;
		}
		catch(e)
		{
			var retValueB64 = getResponseData('SZCAParseCertData', xmlHttp.responseText);
			var retValue = utf8to16(base64decode(retValueB64));
			return retValue;
		}
			
	}
	else
	{
		NotifyClient();
	}
	return "";
}

function SZCAVerifyUserPin(userPin)
{
	var xmlHttp = getHttpObj('SZCAVerifyUserPin');
	var obj = new Object();
	var userPinB64 = base64encode(utf16to8(userPin));
	obj.userPin = userPinB64;
	var data = getRequestData('SZCAVerifyUserPin', obj);
	try
	{
		xmlHttp.send(data);
	}
	catch(e)
	{
		NotifyClient();
		return false;
	}
	if(xmlHttp.status == 200)
	{
		try
		{
			var retValue = getResponseData('SZCAVerifyUserPin', xmlHttp.response);
			return retValue;
		}
		catch(e)
		{
			var retValue = getResponseData('SZCAVerifyUserPin', xmlHttp.responseText);
			return retValue;
		}
			
	}
	else
	{
		NotifyClient();
	}
	return "";
}

 